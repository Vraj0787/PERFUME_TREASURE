package com.perfumetreasure.app.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.google.android.material.snackbar.Snackbar;
import com.perfumetreasure.app.R;
import com.perfumetreasure.app.checkout.PricingEngine;
import com.perfumetreasure.app.models.Order;
import com.perfumetreasure.app.viewmodels.CheckoutViewModel;

/**
 * CheckoutFragment — a single Fragment that hosts the multi-step checkout flow
 * by swapping child views based on {@link CheckoutViewModel.Step}.
 *
 * Layout: {@code res/layout/fragment_checkout.xml}
 *
 * Each step panel is a separate included layout that is shown/hidden:
 *   - layout_step_address   → res/layout/step_address.xml
 *   - layout_step_shipping  → res/layout/step_shipping.xml
 *   - layout_step_coupon    → res/layout/step_coupon.xml
 *   - layout_step_payment   → res/layout/step_payment.xml
 *   - layout_step_review    → res/layout/step_review.xml
 *   - layout_step_confirm   → res/layout/step_confirmation.xml
 *   - progress_bar          → ProgressBar (full-screen overlay)
 */
public class CheckoutFragment extends Fragment {

    private CheckoutViewModel vm;

    // ── Step panels ───────────────────────────────────────────────────────────

    private View stepAddress;
    private View stepShipping;
    private View stepCoupon;
    private View stepPayment;
    private View stepReview;
    private View stepConfirmation;
    private ProgressBar progressBar;

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_checkout, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View root, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(root, savedInstanceState);

        bindPanels(root);
        vm = new ViewModelProvider(requireActivity()).get(CheckoutViewModel.class);
        observeViewModel();
        wireAddressStep(root);
        wireShippingStep(root);
        wireCouponStep(root);
        wirePaymentStep(root);
        wireReviewStep(root);
        wireConfirmationStep(root);
    }

    // ── View binding ──────────────────────────────────────────────────────────

    private void bindPanels(View root) {
        stepAddress      = root.findViewById(R.id.layout_step_address);
        stepShipping     = root.findViewById(R.id.layout_step_shipping);
        stepCoupon       = root.findViewById(R.id.layout_step_coupon);
        stepPayment      = root.findViewById(R.id.layout_step_payment);
        stepReview       = root.findViewById(R.id.layout_step_review);
        stepConfirmation = root.findViewById(R.id.layout_step_confirm);
        progressBar      = root.findViewById(R.id.progress_bar);
    }

    // ── ViewModel observation ─────────────────────────────────────────────────

    private void observeViewModel() {
        vm.getCurrentStep().observe(getViewLifecycleOwner(), this::showStep);

        vm.getIsLoading().observe(getViewLifecycleOwner(), loading -> {
            progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        });

        vm.getErrorMessage().observe(getViewLifecycleOwner(), msg -> {
            if (msg != null && !msg.isEmpty()) {
                Snackbar.make(requireView(), msg, Snackbar.LENGTH_LONG).show();
            }
        });

        vm.getCouponResult().observe(getViewLifecycleOwner(), result -> {
            if (result == null) return;
            TextView tvCouponMsg = stepCoupon.findViewById(R.id.tv_coupon_message);
            if (tvCouponMsg != null) {
                tvCouponMsg.setText(result.getMessage());
                tvCouponMsg.setTextColor(result.isValid()
                    ? getResources().getColor(R.color.success_green, null)
                    : getResources().getColor(R.color.error_red, null));
                tvCouponMsg.setVisibility(View.VISIBLE);
            }
        });

        vm.getOrderPreview().observe(getViewLifecycleOwner(), order -> {
            if (order == null) return;
            populateReviewStep(order);
        });

        vm.getOrderConfirmed().observe(getViewLifecycleOwner(), order -> {
            if (order == null) return;
            populateConfirmationStep(order);
        });
    }

    // ── Step visibility ───────────────────────────────────────────────────────

    private void showStep(CheckoutViewModel.Step step) {
        stepAddress.setVisibility(View.GONE);
        stepShipping.setVisibility(View.GONE);
        stepCoupon.setVisibility(View.GONE);
        stepPayment.setVisibility(View.GONE);
        stepReview.setVisibility(View.GONE);
        stepConfirmation.setVisibility(View.GONE);

        switch (step) {
            case SHIPPING_ADDRESS: stepAddress.setVisibility(View.VISIBLE);      break;
            case SHIPPING_METHOD:  stepShipping.setVisibility(View.VISIBLE);     break;
            case COUPON:           stepCoupon.setVisibility(View.VISIBLE);       break;
            case PAYMENT:          stepPayment.setVisibility(View.VISIBLE);      break;
            case REVIEW:           stepReview.setVisibility(View.VISIBLE);       break;
            case CONFIRMATION:     stepConfirmation.setVisibility(View.VISIBLE); break;
            default: break;
        }
    }

    // ── Step 1: Shipping address ──────────────────────────────────────────────

    private void wireAddressStep(View root) {
        Button btnNext = stepAddress.findViewById(R.id.btn_next_address);
        if (btnNext == null) return;

        btnNext.setOnClickListener(v -> {
            EditText etName     = stepAddress.findViewById(R.id.et_full_name);
            EditText etLine1    = stepAddress.findViewById(R.id.et_line1);
            EditText etCity     = stepAddress.findViewById(R.id.et_city);
            EditText etState    = stepAddress.findViewById(R.id.et_state);
            EditText etPostal   = stepAddress.findViewById(R.id.et_postal_code);
            EditText etCountry  = stepAddress.findViewById(R.id.et_country);
            EditText etPhone    = stepAddress.findViewById(R.id.et_phone);

            Order.ShippingAddress address = new Order.ShippingAddress(
                text(etName), text(etLine1), text(etCity),
                text(etState), text(etPostal), text(etCountry), text(etPhone)
            );
            vm.submitShippingAddress(address);
        });
    }

    // ── Step 2: Shipping method ───────────────────────────────────────────────

    private void wireShippingStep(View root) {
        RadioGroup rgShipping = stepShipping.findViewById(R.id.rg_shipping_method);
        TextView   tvCost     = stepShipping.findViewById(R.id.tv_shipping_cost_preview);
        Button     btnNext    = stepShipping.findViewById(R.id.btn_next_shipping);

        if (rgShipping != null) {
            rgShipping.setOnCheckedChangeListener((group, checkedId) -> {
                PricingEngine.ShippingMethod method;
                if      (checkedId == R.id.rb_express)   method = PricingEngine.ShippingMethod.EXPRESS;
                else if (checkedId == R.id.rb_overnight) method = PricingEngine.ShippingMethod.OVERNIGHT;
                else                                     method = PricingEngine.ShippingMethod.STANDARD;
                vm.selectShippingMethod(method);
            });
        }

        vm.getShippingCost().observe(getViewLifecycleOwner(), cost -> {
            if (tvCost != null) tvCost.setText(cost);
        });

        if (btnNext != null) btnNext.setOnClickListener(v -> vm.confirmShippingMethod());
    }

    // ── Step 3: Coupon ────────────────────────────────────────────────────────

    private void wireCouponStep(View root) {
        EditText etCode  = stepCoupon.findViewById(R.id.et_coupon_code);
        Button btnApply  = stepCoupon.findViewById(R.id.btn_apply_coupon);
        Button btnSkip   = stepCoupon.findViewById(R.id.btn_skip_coupon);
        Button btnNext   = stepCoupon.findViewById(R.id.btn_next_coupon);

        if (btnApply != null && etCode != null) {
            btnApply.setOnClickListener(v -> vm.applyCoupon(text(etCode)));
        }
        if (btnSkip  != null) btnSkip.setOnClickListener(v  -> vm.skipCoupon());
        if (btnNext  != null) btnNext.setOnClickListener(v  -> vm.proceedAfterCoupon());
    }

    // ── Step 4: Payment ───────────────────────────────────────────────────────

    private void wirePaymentStep(View root) {
        Button btnNext = stepPayment.findViewById(R.id.btn_next_payment);
        if (btnNext == null) return;

        btnNext.setOnClickListener(v -> {
            // In production, use your payment SDK token here (Stripe, Braintree, etc.)
            // This sample creates a placeholder card payment.
            EditText etLast4   = stepPayment.findViewById(R.id.et_card_last4);
            EditText etHolder  = stepPayment.findViewById(R.id.et_cardholder_name);

            Order.PaymentMethod method = new Order.PaymentMethod(
                Order.PaymentMethod.Type.CREDIT_CARD,
                "tok_placeholder_" + System.currentTimeMillis()
            );
            if (etLast4  != null) method.setCardLastFour(text(etLast4));
            if (etHolder != null) method.setCardholderName(text(etHolder));

            vm.submitPaymentMethod(method);
        });
    }

    // ── Step 5: Order review ──────────────────────────────────────────────────

    private void populateReviewStep(Order order) {
        setText(stepReview, R.id.tv_review_subtotal,  order.getFormattedSubtotal());
        setText(stepReview, R.id.tv_review_shipping,  order.getFormattedShipping());
        setText(stepReview, R.id.tv_review_tax,       order.getFormattedTax());
        setText(stepReview, R.id.tv_review_total,     order.getFormattedTotal());
        setText(stepReview, R.id.tv_review_address,
                order.getShippingAddress() != null ? order.getShippingAddress().getSummary() : "");
        setText(stepReview, R.id.tv_review_payment,
                order.getPaymentMethod() != null ? order.getPaymentMethod().getDisplayLabel() : "");

        View discountRow = stepReview.findViewById(R.id.row_discount);
        if (discountRow != null) {
            discountRow.setVisibility(order.hasDiscount() ? View.VISIBLE : View.GONE);
            setText(stepReview, R.id.tv_review_discount, order.getFormattedDiscount());
        }
    }

    private void wireReviewStep(View root) {
        Button btnPlace = stepReview.findViewById(R.id.btn_place_order);
        if (btnPlace != null) btnPlace.setOnClickListener(v -> vm.placeOrder());
    }

    // ── Step 6: Confirmation ──────────────────────────────────────────────────

    private void populateConfirmationStep(Order order) {
        setText(stepConfirmation, R.id.tv_order_id,    "#" + order.getOrderId().substring(0, 8).toUpperCase());
        setText(stepConfirmation, R.id.tv_order_total, order.getFormattedTotal());
    }

    private void wireConfirmationStep(View root) {
        Button btnShop = stepConfirmation.findViewById(R.id.btn_continue_shopping);
        if (btnShop != null) {
            btnShop.setOnClickListener(v -> {
                vm.reset();
                Navigation.findNavController(root)
                          .navigate(R.id.action_checkout_to_home);
            });
        }
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    private static String text(EditText et) {
        return et != null ? et.getText().toString().trim() : "";
    }

    private static void setText(View parent, int viewId, String value) {
        TextView tv = parent.findViewById(viewId);
        if (tv != null) tv.setText(value);
    }
}
