package com.perfumetreasure.app.models;

import java.io.Serializable;

/**
 * Represents a single line item inside the shopping cart.
 * Wraps a {@link Perfume} with a chosen quantity.
 */
public class CartItem implements Serializable {

    private Perfume perfume;
    private int quantity;
    private long addedAtMs;   // epoch millis – useful for sort / analytics

    public CartItem(Perfume perfume, int quantity) {
        if (perfume == null)   throw new IllegalArgumentException("Perfume cannot be null.");
        if (quantity <= 0)     throw new IllegalArgumentException("Quantity must be > 0.");
        this.perfume    = perfume;
        this.quantity   = quantity;
        this.addedAtMs  = System.currentTimeMillis();
    }

    // ─── Computed helpers ───────────────────────────────────────────────────────

    /** Total cost for this line item */
    public double getLineTotal() {
        return perfume.getPrice() * quantity;
    }

    /** Formatted line total: "$179.98" */
    public String getFormattedLineTotal() {
        return String.format("$%.2f", getLineTotal());
    }

    /** True when the requested quantity exceeds available stock */
    public boolean exceedsStock() {
        return quantity > perfume.getStockQuantity();
    }

    // ─── Mutators ───────────────────────────────────────────────────────────────

    /**
     * Increment quantity by {@code delta}.
     * Throws if this would exceed available stock.
     */
    public void incrementQuantity(int delta) {
        int next = this.quantity + delta;
        if (next > perfume.getStockQuantity()) {
            throw new IllegalStateException(
                "Only " + perfume.getStockQuantity() + " units available for "" + perfume.getName() + "".");
        }
        this.quantity = next;
    }

    public void decrementQuantity(int delta) {
        int next = this.quantity - delta;
        if (next < 1) throw new IllegalStateException("Quantity cannot drop below 1.");
        this.quantity = next;
    }

    public void setQuantity(int quantity) {
        if (quantity < 1) throw new IllegalArgumentException("Quantity must be >= 1.");
        this.quantity = quantity;
    }

    // ─── Getters ────────────────────────────────────────────────────────────────

    public Perfume getPerfume()  { return perfume; }
    public int getQuantity()     { return quantity; }
    public long getAddedAtMs()   { return addedAtMs; }
}
