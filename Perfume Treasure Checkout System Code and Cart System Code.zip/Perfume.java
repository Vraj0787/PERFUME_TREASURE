package com.perfumetreasure.app.models;

import java.io.Serializable;
import java.util.List;

/**
 * Represents a perfume product in the PerfumeTreasure app.
 */
public class Perfume implements Serializable {

    private String id;
    private String name;
    private String brand;
    private String description;
    private double price;
    private String imageUrl;
    private List<String> scentNotes;       // e.g., ["Bergamot", "Rose", "Musk"]
    private String concentration;          // e.g., "Eau de Parfum", "Eau de Toilette"
    private int volumeMl;                  // e.g., 50, 100
    private float rating;
    private int reviewCount;
    private boolean inStock;
    private int stockQuantity;

    public Perfume() {}

    public Perfume(String id, String name, String brand, double price,
                   String imageUrl, String concentration, int volumeMl) {
        this.id = id;
        this.name = name;
        this.brand = brand;
        this.price = price;
        this.imageUrl = imageUrl;
        this.concentration = concentration;
        this.volumeMl = volumeMl;
        this.inStock = true;
        this.stockQuantity = 100;
    }

    // ─── Getters ────────────────────────────────────────────────────────────────

    public String getId()             { return id; }
    public String getName()           { return name; }
    public String getBrand()          { return brand; }
    public String getDescription()    { return description; }
    public double getPrice()          { return price; }
    public String getImageUrl()       { return imageUrl; }
    public List<String> getScentNotes() { return scentNotes; }
    public String getConcentration()  { return concentration; }
    public int getVolumeMl()          { return volumeMl; }
    public float getRating()          { return rating; }
    public int getReviewCount()       { return reviewCount; }
    public boolean isInStock()        { return inStock; }
    public int getStockQuantity()     { return stockQuantity; }

    /** Formatted display name: "Brand – Name (100ml EDP)" */
    public String getDisplayTitle() {
        return brand + " – " + name + " (" + volumeMl + "ml " + concentration + ")";
    }

    /** Formatted price string: "$89.99" */
    public String getFormattedPrice() {
        return String.format("$%.2f", price);
    }

    // ─── Setters ────────────────────────────────────────────────────────────────

    public void setId(String id)                       { this.id = id; }
    public void setName(String name)                   { this.name = name; }
    public void setBrand(String brand)                 { this.brand = brand; }
    public void setDescription(String description)     { this.description = description; }
    public void setPrice(double price)                 { this.price = price; }
    public void setImageUrl(String imageUrl)           { this.imageUrl = imageUrl; }
    public void setScentNotes(List<String> notes)      { this.scentNotes = notes; }
    public void setConcentration(String concentration) { this.concentration = concentration; }
    public void setVolumeMl(int volumeMl)              { this.volumeMl = volumeMl; }
    public void setRating(float rating)                { this.rating = rating; }
    public void setReviewCount(int reviewCount)        { this.reviewCount = reviewCount; }
    public void setInStock(boolean inStock)            { this.inStock = inStock; }
    public void setStockQuantity(int qty)              { this.stockQuantity = qty; }
}
