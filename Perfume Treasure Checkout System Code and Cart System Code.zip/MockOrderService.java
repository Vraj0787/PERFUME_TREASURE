package com.perfumetreasure.app.services;

import com.perfumetreasure.app.checkout.CheckoutManager;
import com.perfumetreasure.app.models.Order;

import java.util.concurrent.Executors;

/**
 * MockOrderService — simulates a network order submission.
 *
 * In production replace the body of {@link #submitOrder} with a Retrofit /
 * Ktor call to your backend. The {@link CheckoutManager.OrderCallback}
 * contract stays the same.
 */
public class MockOrderService implements CheckoutManager.OrderService {

    private static final long SIMULATED_DELAY_MS = 2_000;

    @Override
    public void submitOrder(Order order, CheckoutManager.OrderCallback callback) {
        // Simulate async network call on a background thread
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                Thread.sleep(SIMULATED_DELAY_MS);

                // ── Mock success path (95 % of the time) ──────────────────────
                if (Math.random() > 0.05) {
                    order.setStatus(Order.Status.CONFIRMED);
                    order.setTrackingNumber("SL-" +
                        Long.toHexString(System.currentTimeMillis()).toUpperCase());
                    callback.onSuccess(order);
                } else {
                    // ── Mock failure path ──────────────────────────────────────
                    callback.onFailure("Payment declined. Please check your card details.");
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                callback.onFailure("Request was interrupted. Please try again.");
            }
        });
    }
}
