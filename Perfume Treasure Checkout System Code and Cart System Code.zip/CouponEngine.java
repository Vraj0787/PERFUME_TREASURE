package com.perfumetreasure.app.checkout;

import com.perfumetreasure.app.models.CartItem;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * CouponEngine — validates coupon codes and computes discount amounts.
 *
 * In a production app the coupon catalogue would come from the backend.
 * This class shows the pattern; swap {@link #loadCoupons()} for an API call.
 */
public class CouponEngine {

    // ── Coupon model ─────────────────────────────────────────────────────────

    public enum DiscountType { PERCENTAGE, FIXED_AMOUNT, FREE_SHIPPING }

    public static class Coupon {
        private final String       code;
        private final DiscountType type;
        private final double       value;          // % (0-100) or $ amount
        private final double       minimumOrder;   // 0 = no minimum
        private final boolean      active;

        public Coupon(String code, DiscountType type, double value,
                      double minimumOrder, boolean active) {
            this.code         = code;
            this.type         = type;
            this.value        = value;
            this.minimumOrder = minimumOrder;
            this.active       = active;
        }

        public String       getCode()         { return code; }
        public DiscountType getType()         { return type; }
        public double       getValue()        { return value; }
        public double       getMinimumOrder() { return minimumOrder; }
        public boolean      isActive()        { return active; }
    }

    // ── Result model ─────────────────────────────────────────────────────────

    public static class CouponResult {
        private final boolean valid;
        private final double  discountAmount;  // 0 for free-shipping coupons
        private final boolean freeShipping;
        private final String  message;
        private final Coupon  coupon;

        private CouponResult(boolean valid, double discountAmount, boolean freeShipping,
                              String message, Coupon coupon) {
            this.valid          = valid;
            this.discountAmount = discountAmount;
            this.freeShipping   = freeShipping;
            this.message        = message;
            this.coupon         = coupon;
        }

        public static CouponResult success(double amount, boolean freeShip, Coupon c) {
            String msg = freeShip ? "Free shipping applied!" :
                         String.format("You saved $%.2f!", amount);
            return new CouponResult(true, amount, freeShip, msg, c);
        }

        public static CouponResult failure(String reason) {
            return new CouponResult(false, 0, false, reason, null);
        }

        public boolean isValid()           { return valid; }
        public double  getDiscountAmount() { return discountAmount; }
        public boolean isFreeShipping()    { return freeShipping; }
        public String  getMessage()        { return message; }
        public Coupon  getCoupon()         { return coupon; }
    }

    // ── Catalogue (mock) ─────────────────────────────────────────────────────

    private final Map<String, Coupon> catalogue = new HashMap<>();

    public CouponEngine() {
        loadCoupons();
    }

    private void loadCoupons() {
        addCoupon("WELCOME10",   DiscountType.PERCENTAGE,   10,  0,   true);
        addCoupon("LUXE20",      DiscountType.PERCENTAGE,   20,  150, true);
        addCoupon("SAVE15",      DiscountType.FIXED_AMOUNT, 15,  75,  true);
        addCoupon("FREESHIP",    DiscountType.FREE_SHIPPING, 0,  50,  true);
        addCoupon("SUMMER25",    DiscountType.PERCENTAGE,   25,  200, true);
    }

    private void addCoupon(String code, DiscountType type, double value,
                           double min, boolean active) {
        catalogue.put(code.toUpperCase(), new Coupon(code.toUpperCase(), type, value, min, active));
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Validate {@code code} against the current cart subtotal.
     *
     * @param code     the coupon code entered by the user (case-insensitive)
     * @param subtotal the pre-discount cart subtotal
     * @param items    cart items (reserved for item-specific coupons in future)
     * @return a {@link CouponResult} — always non-null
     */
    public CouponResult apply(String code, double subtotal, List<CartItem> items) {
        if (code == null || code.isBlank()) {
            return CouponResult.failure("Please enter a coupon code.");
        }

        Coupon coupon = catalogue.get(code.trim().toUpperCase());

        if (coupon == null)       return CouponResult.failure("Coupon code not recognised.");
        if (!coupon.isActive())   return CouponResult.failure("This coupon has expired.");
        if (subtotal < coupon.getMinimumOrder()) {
            return CouponResult.failure(
                String.format("Minimum order of $%.2f required for this coupon.", coupon.getMinimumOrder()));
        }

        switch (coupon.getType()) {
            case PERCENTAGE:
                double pctDiscount = subtotal * (coupon.getValue() / 100.0);
                return CouponResult.success(pctDiscount, false, coupon);

            case FIXED_AMOUNT:
                double fixedDiscount = Math.min(coupon.getValue(), subtotal); // never negative total
                return CouponResult.success(fixedDiscount, false, coupon);

            case FREE_SHIPPING:
                return CouponResult.success(0, true, coupon);

            default:
                return CouponResult.failure("Unknown coupon type.");
        }
    }
}
