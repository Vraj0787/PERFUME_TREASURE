package com.perfumetreasure.app.viewmodels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.perfumetreasure.app.cart.CartManager;
import com.perfumetreasure.app.checkout.CheckoutManager;
import com.perfumetreasure.app.checkout.CouponEngine;
import com.perfumetreasure.app.checkout.PricingEngine;
import com.perfumetreasure.app.models.Order;

/**
 * CheckoutViewModel — drives the multi-step checkout flow.
 *
 * Screen flow managed here:
 *   Shipping Address → Shipping Method → (Coupon) → Payment → Review → Confirmation
 *
 * Observe {@link #getCurrentStep()} to know which screen to show.
 * Observe {@link #getOrderPreview()} to populate the order-summary screen.
 * Observe {@link #getOrderConfirmed()} for the success screen.
 */
public class CheckoutViewModel extends ViewModel {

    // ── Checkout steps ────────────────────────────────────────────────────────

    public enum Step {
        SHIPPING_ADDRESS,
        SHIPPING_METHOD,
        COUPON,
        PAYMENT,
        REVIEW,
        CONFIRMATION,
        ERROR
    }

    // ── Dependencies ──────────────────────────────────────────────────────────

    private final CheckoutManager checkoutManager;

    public CheckoutViewModel(CheckoutManager checkoutManager) {
        this.checkoutManager = checkoutManager;
    }

    // ── LiveData ─────────────────────────────────────────────────────────────

    private final MutableLiveData<Step>                    currentStep    = new MutableLiveData<>(Step.SHIPPING_ADDRESS);
    private final MutableLiveData<Order>                   orderPreview   = new MutableLiveData<>();
    private final MutableLiveData<Order>                   orderConfirmed = new MutableLiveData<>();
    private final MutableLiveData<String>                  errorMessage   = new MutableLiveData<>();
    private final MutableLiveData<Boolean>                 isLoading      = new MutableLiveData<>(false);
    private final MutableLiveData<CouponEngine.CouponResult> couponResult = new MutableLiveData<>();
    private final MutableLiveData<String>                  shippingCost   = new MutableLiveData<>("$7.99");

    // ── Exposed LiveData ──────────────────────────────────────────────────────

    public LiveData<Step>                          getCurrentStep()    { return currentStep; }
    public LiveData<Order>                         getOrderPreview()   { return orderPreview; }
    public LiveData<Order>                         getOrderConfirmed() { return orderConfirmed; }
    public LiveData<String>                        getErrorMessage()   { return errorMessage; }
    public LiveData<Boolean>                       getIsLoading()      { return isLoading; }
    public LiveData<CouponEngine.CouponResult>     getCouponResult()   { return couponResult; }
    public LiveData<String>                        getShippingCost()   { return shippingCost; }

    // ── Step 1: Shipping address ──────────────────────────────────────────────

    public void submitShippingAddress(Order.ShippingAddress address) {
        try {
            checkoutManager.setShippingAddress(address);
            currentStep.setValue(Step.SHIPPING_METHOD);
        } catch (IllegalArgumentException e) {
            errorMessage.setValue(e.getMessage());
        }
    }

    // ── Step 2: Shipping method ───────────────────────────────────────────────

    public void selectShippingMethod(PricingEngine.ShippingMethod method) {
        checkoutManager.setShippingMethod(method);
        double cost = checkoutManager.getShippingCostPreview();
        shippingCost.setValue(cost == 0 ? "FREE" : String.format("$%.2f", cost));
    }

    public void confirmShippingMethod() {
        currentStep.setValue(Step.COUPON);
    }

    // ── Step 3: Coupon (optional) ─────────────────────────────────────────────

    public void applyCoupon(String code) {
        CouponEngine.CouponResult result = checkoutManager.applyCoupon(code);
        couponResult.setValue(result);
        if (result.isValid()) {
            // Refresh shipping cost display (might become free)
            double cost = checkoutManager.getShippingCostPreview();
            shippingCost.setValue(cost == 0 ? "FREE" : String.format("$%.2f", cost));
        }
    }

    public void removeCoupon() {
        checkoutManager.removeCoupon();
        couponResult.setValue(null);
        double cost = checkoutManager.getShippingCostPreview();
        shippingCost.setValue(cost == 0 ? "FREE" : String.format("$%.2f", cost));
    }

    public void skipCoupon() {
        currentStep.setValue(Step.PAYMENT);
    }

    public void proceedAfterCoupon() {
        currentStep.setValue(Step.PAYMENT);
    }

    // ── Step 4: Payment method ────────────────────────────────────────────────

    public void submitPaymentMethod(Order.PaymentMethod method) {
        try {
            checkoutManager.setPaymentMethod(method);
            buildPreviewAndNavigate();
        } catch (IllegalArgumentException e) {
            errorMessage.setValue(e.getMessage());
        }
    }

    // ── Step 5: Order review ──────────────────────────────────────────────────

    private void buildPreviewAndNavigate() {
        try {
            Order preview = checkoutManager.buildOrderPreview();
            orderPreview.setValue(preview);
            currentStep.setValue(Step.REVIEW);
        } catch (IllegalStateException e) {
            errorMessage.setValue(e.getMessage());
        }
    }

    // ── Step 6: Place order ───────────────────────────────────────────────────

    public void placeOrder() {
        isLoading.setValue(true);
        checkoutManager.placeOrder(new CheckoutManager.OrderCallback() {
            @Override
            public void onSuccess(Order confirmedOrder) {
                isLoading.postValue(false);
                orderConfirmed.postValue(confirmedOrder);
                currentStep.postValue(Step.CONFIRMATION);
            }

            @Override
            public void onFailure(String errorMsg) {
                isLoading.postValue(false);
                errorMessage.postValue(errorMsg);
            }
        });
    }

    // ── Navigation helpers ────────────────────────────────────────────────────

    public void goBack() {
        Step step = currentStep.getValue();
        if (step == null) return;
        switch (step) {
            case SHIPPING_METHOD: currentStep.setValue(Step.SHIPPING_ADDRESS); break;
            case COUPON:          currentStep.setValue(Step.SHIPPING_METHOD);  break;
            case PAYMENT:         currentStep.setValue(Step.COUPON);            break;
            case REVIEW:          currentStep.setValue(Step.PAYMENT);           break;
            default: break;
        }
    }

    public void reset() {
        checkoutManager.reset();
        currentStep.setValue(Step.SHIPPING_ADDRESS);
        orderPreview.setValue(null);
        orderConfirmed.setValue(null);
        errorMessage.setValue(null);
        couponResult.setValue(null);
        isLoading.setValue(false);
    }
}
