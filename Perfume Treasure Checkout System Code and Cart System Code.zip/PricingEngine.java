package com.perfumetreasure.app.checkout;

import com.perfumetreasure.app.models.Order;

/**
 * PricingEngine — computes shipping cost and sales tax, then assembles
 * the final order totals.
 *
 * Rules are intentionally simple and easy to swap for server-side logic.
 */
public class PricingEngine {

    // ── Shipping tiers ────────────────────────────────────────────────────────

    /** Orders ≥ this threshold ship free (before discounts). */
    public static final double FREE_SHIPPING_THRESHOLD = 100.0;

    public static final double STANDARD_SHIPPING = 7.99;
    public static final double EXPRESS_SHIPPING   = 14.99;
    public static final double OVERNIGHT_SHIPPING = 24.99;

    public enum ShippingMethod { STANDARD, EXPRESS, OVERNIGHT }

    // ── Tax rates by country / state (sample) ────────────────────────────────

    private static final double DEFAULT_TAX_RATE = 0.08;   // 8 %

    private double taxRateFor(String country, String state) {
        if ("US".equalsIgnoreCase(country)) {
            switch (state != null ? state.toUpperCase() : "") {
                case "CA": return 0.0725;
                case "NY": return 0.08;
                case "TX": return 0.0625;
                case "FL": return 0.06;
                case "OR": return 0.0;   // Oregon has no sales tax
                default:   return DEFAULT_TAX_RATE;
            }
        }
        if ("GB".equalsIgnoreCase(country)) return 0.20;   // UK VAT
        if ("DE".equalsIgnoreCase(country)) return 0.19;   // German VAT
        return DEFAULT_TAX_RATE;
    }

    // ── Result ────────────────────────────────────────────────────────────────

    public static class PricingResult {
        public final double subtotal;
        public final double discountAmount;
        public final double shippingCost;
        public final double taxAmount;
        public final double total;

        public PricingResult(double subtotal, double discountAmount,
                             double shippingCost, double taxAmount) {
            this.subtotal       = subtotal;
            this.discountAmount = discountAmount;
            this.shippingCost   = shippingCost;
            double taxable      = Math.max(subtotal - discountAmount, 0);
            this.taxAmount      = taxAmount;
            this.total          = taxable + shippingCost + taxAmount;
        }

        public String getFormattedTotal() { return String.format("$%.2f", total); }
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Compute shipping cost.
     *
     * @param subtotal        raw subtotal (before any discount)
     * @param method          selected shipping method
     * @param freeShipping    true when a free-shipping coupon is applied
     */
    public double calculateShipping(double subtotal,
                                    ShippingMethod method,
                                    boolean freeShipping) {
        if (freeShipping || subtotal >= FREE_SHIPPING_THRESHOLD) return 0.0;
        switch (method) {
            case EXPRESS:   return EXPRESS_SHIPPING;
            case OVERNIGHT: return OVERNIGHT_SHIPPING;
            default:        return STANDARD_SHIPPING;
        }
    }

    /**
     * Compute sales tax on the discounted subtotal.
     *
     * @param discountedSubtotal subtotal after coupon discount
     * @param shippingCost       shipping is taxable in some jurisdictions (simplified here)
     * @param address            used to determine the applicable tax rate
     */
    public double calculateTax(double discountedSubtotal,
                               double shippingCost,
                               Order.ShippingAddress address) {
        if (address == null) return discountedSubtotal * DEFAULT_TAX_RATE;
        double rate = taxRateFor(address.getCountry(), address.getState());
        return (discountedSubtotal + shippingCost) * rate;
    }

    /**
     * Full pricing pass — call this to populate an {@link Order} before
     * presenting the order-summary screen.
     */
    public PricingResult calculate(double subtotal,
                                   double discountAmount,
                                   ShippingMethod shippingMethod,
                                   boolean freeShipping,
                                   Order.ShippingAddress address) {
        double discounted = Math.max(subtotal - discountAmount, 0);
        double shipping   = calculateShipping(subtotal, shippingMethod, freeShipping);
        double tax        = calculateTax(discounted, shipping, address);
        return new PricingResult(subtotal, discountAmount, shipping, tax);
    }

    /** Apply a {@link PricingResult} directly onto an {@link Order}. */
    public void applyToOrder(Order order, PricingResult result) {
        order.setSubtotal(result.subtotal);
        order.setDiscountAmount(result.discountAmount);
        order.setShippingCost(result.shippingCost);
        order.setTaxAmount(result.taxAmount);
        order.setTotal(result.total);
    }
}
