package com.perfumetreasure.app.ui;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.perfumetreasure.app.cart.CartManager;
import com.perfumetreasure.app.checkout.CheckoutManager;
import com.perfumetreasure.app.checkout.CouponEngine;
import com.perfumetreasure.app.checkout.PricingEngine;
import com.perfumetreasure.app.services.MockOrderService;
import com.perfumetreasure.app.viewmodels.CartViewModel;
import com.perfumetreasure.app.viewmodels.CheckoutViewModel;

/**
 * PerfumeTreasureViewModelFactory — wires together all dependencies and vends
 * the correct ViewModel subclass.
 *
 * Register once at the Activity level so all child Fragments share state:
 *
 * <pre>
 *   PerfumeTreasureViewModelFactory factory = new PerfumeTreasureViewModelFactory();
 *   CartViewModel     cart     = new ViewModelProvider(this, factory).get(CartViewModel.class);
 *   CheckoutViewModel checkout = new ViewModelProvider(this, factory).get(CheckoutViewModel.class);
 * </pre>
 */
public class PerfumeTreasureViewModelFactory implements ViewModelProvider.Factory {

    // Shared singleton services
    private final CartManager      cartManager;
    private final CheckoutManager  checkoutManager;

    public PerfumeTreasureViewModelFactory() {
        cartManager = CartManager.getInstance();

        CheckoutManager cm = new CheckoutManager(
            cartManager,
            new CouponEngine(),
            new PricingEngine(),
            new MockOrderService()   // swap for real service in production
        );
        this.checkoutManager = cm;
    }

    @NonNull
    @Override
    @SuppressWarnings("unchecked")
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        if (modelClass.isAssignableFrom(CartViewModel.class)) {
            return (T) new CartViewModel();
        }
        if (modelClass.isAssignableFrom(CheckoutViewModel.class)) {
            return (T) new CheckoutViewModel(checkoutManager);
        }
        throw new IllegalArgumentException("Unknown ViewModel: " + modelClass.getName());
    }
}
