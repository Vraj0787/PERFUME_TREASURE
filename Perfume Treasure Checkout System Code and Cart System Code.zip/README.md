# PerfumeTreasure — Cart & Checkout System (Java / Android)

A production-ready cart and checkout system for a luxury perfume mobile app.
Built with clean separation of concerns, MVVM architecture, and full Android
Jetpack integration.

---

## Project Structure

```
com.perfumetreasure.app/
├── models/
│   ├── Perfume.java            — Product domain model
│   ├── CartItem.java           — Line item (Perfume + quantity)
│   └── Order.java              — Full order + nested ShippingAddress & PaymentMethod
│
├── cart/
│   └── CartManager.java        — Thread-safe singleton cart (add/remove/update/notify)
│
├── checkout/
│   ├── CouponEngine.java       — Coupon validation & discount calculation
│   ├── PricingEngine.java      — Shipping tiers, tax by region, order totals
│   └── CheckoutManager.java   — Multi-step checkout orchestrator
│
├── viewmodels/
│   ├── CartViewModel.java      — LiveData bridge for Cart screen
│   └── CheckoutViewModel.java — LiveData bridge for Checkout flow (step machine)
│
├── ui/
│   ├── PerfumeTreasureViewModelFactory.java  — Dependency injection / ViewModel factory
│   ├── adapters/
│   │   └── CartAdapter.java           — RecyclerView adapter (DiffUtil)
│   └── fragments/
│       ├── CartFragment.java          — Cart screen Fragment
│       └── CheckoutFragment.java     — Multi-step checkout Fragment
│
└── services/
    └── MockOrderService.java   — Simulated async order submission
```

---

## Architecture

```
UI Layer (Fragments / Adapters)
        │  observe LiveData
        ▼
ViewModel Layer (CartViewModel, CheckoutViewModel)
        │  calls
        ▼
Business Logic (CartManager, CheckoutManager, CouponEngine, PricingEngine)
        │  reads / writes
        ▼
Domain Models (Perfume, CartItem, Order)
        │  submitted via
        ▼
Service Layer (OrderService → your backend API)
```

---

## Checkout Flow

```
[Cart] ──▶ [Shipping Address] ──▶ [Shipping Method]
              ──▶ [Coupon (optional)] ──▶ [Payment]
                    ──▶ [Order Review] ──▶ [Confirmation]
```

Each step is a LiveData-driven panel inside `CheckoutFragment`.
`CheckoutViewModel.Step` is the single source of truth for which panel is visible.

---

## Quick Integration Guide

### 1. Add to your Activity

```java
PerfumeTreasureViewModelFactory factory = new PerfumeTreasureViewModelFactory();
// Share the factory with all child Fragments via ViewModelProvider
```

### 2. Add a perfume to the cart (e.g. from a Product Detail screen)

```java
CartViewModel cartVm = new ViewModelProvider(requireActivity(), factory)
                           .get(CartViewModel.class);

cartVm.addToCart(perfume, 1);
```

### 3. Observe cart badge count on your bottom nav

```java
cartVm.getItemCount().observe(this, count -> {
    badge.setNumber(count);
    badge.setVisible(count > 0);
});
```

### 4. Navigate to checkout

```java
// In your nav_graph.xml, add:
//   action id="action_cart_to_checkout"  destination="checkoutFragment"
//   action id="action_checkout_to_home"  destination="homeFragment"
Navigation.findNavController(view).navigate(R.id.action_cart_to_checkout);
```

### 5. Replace MockOrderService with your real backend

```java
// Implement CheckoutManager.OrderService with Retrofit:
public class RetrofitOrderService implements CheckoutManager.OrderService {
    @Override
    public void submitOrder(Order order, OrderCallback callback) {
        api.placeOrder(order).enqueue(new Callback<Order>() {
            public void onResponse(Call<Order> call, Response<Order> response) {
                if (response.isSuccessful()) callback.onSuccess(response.body());
                else callback.onFailure("Server error: " + response.code());
            }
            public void onFailure(Call<Order> call, Throwable t) {
                callback.onFailure(t.getMessage());
            }
        });
    }
}
```

---

## Coupon Codes (built-in for testing)

| Code        | Type        | Value | Min. Order |
|-------------|-------------|-------|------------|
| WELCOME10   | Percentage  | 10%   | None       |
| LUXE20      | Percentage  | 20%   | $150       |
| SAVE15      | Fixed       | $15   | $75        |
| FREESHIP    | Free ship   | —     | $50        |
| SUMMER25    | Percentage  | 25%   | $200       |

---

## Shipping Tiers

| Method    | Cost   | Notes                              |
|-----------|--------|------------------------------------|
| Standard  | $7.99  | Free on orders ≥ $100              |
| Express   | $14.99 |                                    |
| Overnight | $24.99 |                                    |

---

## Dependencies (add to build.gradle)

```groovy
dependencies {
    // Architecture Components
    implementation "androidx.lifecycle:lifecycle-viewmodel:2.7.0"
    implementation "androidx.lifecycle:lifecycle-livedata:2.7.0"

    // Navigation
    implementation "androidx.navigation:navigation-fragment:2.7.0"
    implementation "androidx.navigation:navigation-ui:2.7.0"

    // RecyclerView
    implementation "androidx.recyclerview:recyclerview:1.3.2"

    // Material Design (Snackbar, RadioButton, etc.)
    implementation "com.google.android.material:material:1.11.0"

    // Image loading (choose one)
    implementation "com.github.bumptech.glide:glide:4.16.0"
    // OR: implementation "io.coil-kt:coil:2.6.0"
}
```

---

## Layout File Checklist

The Java code references these layout XML files — create them in `res/layout/`:

| File                      | Used by              |
|---------------------------|----------------------|
| `item_cart.xml`           | CartAdapter          |
| `fragment_cart.xml`       | CartFragment         |
| `fragment_checkout.xml`   | CheckoutFragment     |
| `step_address.xml`        | CheckoutFragment     |
| `step_shipping.xml`       | CheckoutFragment     |
| `step_coupon.xml`         | CheckoutFragment     |
| `step_payment.xml`        | CheckoutFragment     |
| `step_review.xml`         | CheckoutFragment     |
| `step_confirmation.xml`   | CheckoutFragment     |

---

## Security Notes

- **Never store raw card numbers** — always tokenise via Stripe/Braintree SDK before
  passing a `PaymentMethod` to `CheckoutManager`.
- The `paymentToken` field in `Order.PaymentMethod` is the only card data that
  should leave the device.
- Coupon validation should always be **re-verified server-side** before charging.
