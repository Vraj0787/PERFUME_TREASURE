package com.perfumetreasure.app.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;
import com.perfumetreasure.app.R;
import com.perfumetreasure.app.ui.adapters.CartAdapter;
import com.perfumetreasure.app.viewmodels.CartViewModel;

/**
 * CartFragment — displays the shopping cart.
 *
 * Layout file: {@code res/layout/fragment_cart.xml}
 *
 * Required view IDs:
 *   - rv_cart_items         (RecyclerView)
 *   - tv_subtotal           (TextView)
 *   - tv_item_count         (TextView)
 *   - btn_checkout          (Button)
 *   - layout_empty_cart     (View) — shown when cart is empty
 *   - layout_cart_content   (View) — shown when cart has items
 */
public class CartFragment extends Fragment implements CartAdapter.CartItemListener {

    private CartViewModel cartViewModel;
    private CartAdapter   cartAdapter;

    // ── Views ─────────────────────────────────────────────────────────────────

    private RecyclerView rv;
    private TextView     tvSubtotal;
    private TextView     tvItemCount;
    private Button       btnCheckout;
    private View         layoutEmpty;
    private View         layoutContent;

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_cart, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        bindViews(view);
        setupRecyclerView();
        setupViewModel();
        setupCheckoutButton(view);
    }

    // ── Setup ─────────────────────────────────────────────────────────────────

    private void bindViews(View root) {
        rv             = root.findViewById(R.id.rv_cart_items);
        tvSubtotal     = root.findViewById(R.id.tv_subtotal);
        tvItemCount    = root.findViewById(R.id.tv_item_count);
        btnCheckout    = root.findViewById(R.id.btn_checkout);
        layoutEmpty    = root.findViewById(R.id.layout_empty_cart);
        layoutContent  = root.findViewById(R.id.layout_cart_content);
    }

    private void setupRecyclerView() {
        cartAdapter = new CartAdapter(this);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        rv.setAdapter(cartAdapter);
        rv.setHasFixedSize(false);
    }

    private void setupViewModel() {
        cartViewModel = new ViewModelProvider(requireActivity()).get(CartViewModel.class);

        cartViewModel.getCartItems().observe(getViewLifecycleOwner(), items -> {
            cartAdapter.submitList(items);
            boolean empty = items == null || items.isEmpty();
            layoutEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
            layoutContent.setVisibility(empty ? View.GONE : View.VISIBLE);
            btnCheckout.setEnabled(!empty);
        });

        cartViewModel.getSubtotal().observe(getViewLifecycleOwner(), s ->
            tvSubtotal.setText(s));

        cartViewModel.getItemCount().observe(getViewLifecycleOwner(), count -> {
            String label = count == 1 ? "1 item" : count + " items";
            tvItemCount.setText(label);
        });

        cartViewModel.getErrorMessage().observe(getViewLifecycleOwner(), msg -> {
            if (msg != null && !msg.isEmpty()) {
                Snackbar.make(requireView(), msg, Snackbar.LENGTH_LONG).show();
            }
        });
    }

    private void setupCheckoutButton(View root) {
        btnCheckout.setOnClickListener(v ->
            Navigation.findNavController(root)
                      .navigate(R.id.action_cart_to_checkout));
    }

    // ── CartItemListener ──────────────────────────────────────────────────────

    @Override
    public void onIncrement(String perfumeId) {
        cartViewModel.incrementItem(perfumeId);
    }

    @Override
    public void onDecrement(String perfumeId) {
        cartViewModel.decrementItem(perfumeId);
    }

    @Override
    public void onRemove(String perfumeId) {
        cartViewModel.removeFromCart(perfumeId);
        Snackbar.make(requireView(), "Item removed", Snackbar.LENGTH_SHORT)
                .setAction("Undo", v -> {
                    // In a full implementation, restore the item here.
                })
                .show();
    }
}
