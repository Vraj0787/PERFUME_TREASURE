package com.perfumetreasure.app.viewmodels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.perfumetreasure.app.cart.CartManager;
import com.perfumetreasure.app.models.CartItem;
import com.perfumetreasure.app.models.Perfume;

import java.util.List;

/**
 * CartViewModel — exposes cart state to the Cart screen via LiveData.
 *
 * Works with Android's Architecture Components (AAC) ViewModel.
 * Observe the exposed LiveData streams from your Fragment/Activity.
 *
 * Usage (Fragment):
 * <pre>
 *   CartViewModel vm = new ViewModelProvider(this).get(CartViewModel.class);
 *   vm.getCartItems().observe(getViewLifecycleOwner(), items -> adapter.submitList(items));
 *   vm.getSubtotal().observe(getViewLifecycleOwner(), s -> subtotalText.setText(s));
 * </pre>
 */
public class CartViewModel extends ViewModel {

    private final CartManager cartManager = CartManager.getInstance();

    // ── LiveData ─────────────────────────────────────────────────────────────

    private final MutableLiveData<List<CartItem>> cartItems   = new MutableLiveData<>();
    private final MutableLiveData<Integer>        itemCount   = new MutableLiveData<>(0);
    private final MutableLiveData<String>         subtotal    = new MutableLiveData<>("$0.00");
    private final MutableLiveData<String>         errorMessage = new MutableLiveData<>();

    // ── Constructor ──────────────────────────────────────────────────────────

    public CartViewModel() {
        // Register listener so LiveData updates any time the cart changes
        cartManager.addListener((items, count, sub) -> {
            cartItems.postValue(items);
            itemCount.postValue(count);
            subtotal.postValue(String.format("$%.2f", sub));
        });

        // Seed with current values in case cart already has items
        refresh();
    }

    // ── Exposed LiveData (read-only) ──────────────────────────────────────────

    public LiveData<List<CartItem>> getCartItems()    { return cartItems; }
    public LiveData<Integer>        getItemCount()    { return itemCount; }
    public LiveData<String>         getSubtotal()     { return subtotal; }
    public LiveData<String>         getErrorMessage() { return errorMessage; }

    // ── User actions ─────────────────────────────────────────────────────────

    public void addToCart(Perfume perfume, int qty) {
        try {
            cartManager.addItem(perfume, qty);
        } catch (Exception e) {
            errorMessage.postValue(e.getMessage());
        }
    }

    public void addToCart(Perfume perfume) {
        addToCart(perfume, 1);
    }

    public void removeFromCart(String perfumeId) {
        cartManager.removeItem(perfumeId);
    }

    public void incrementItem(String perfumeId) {
        try {
            cartManager.incrementItem(perfumeId);
        } catch (Exception e) {
            errorMessage.postValue(e.getMessage());
        }
    }

    public void decrementItem(String perfumeId) {
        cartManager.decrementItem(perfumeId);
    }

    public void updateQuantity(String perfumeId, int qty) {
        try {
            cartManager.updateQuantity(perfumeId, qty);
        } catch (Exception e) {
            errorMessage.postValue(e.getMessage());
        }
    }

    public void clearCart() {
        cartManager.clearCart();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void refresh() {
        cartItems.postValue(cartManager.getItems());
        itemCount.postValue(cartManager.getTotalItemCount());
        subtotal.postValue(cartManager.getFormattedSubtotal());
    }

    public boolean isEmpty() { return cartManager.isEmpty(); }

    /** Check if a perfume is already in the cart (for "Add to Cart" button state). */
    public boolean isInCart(String perfumeId) {
        return cartManager.containsPerfume(perfumeId);
    }

    public int getQuantityInCart(String perfumeId) {
        return cartManager.getQuantityFor(perfumeId);
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        // ViewModel is being destroyed — listener will be GC'd with it.
        // Explicit removal is good practice for safety:
        cartManager.removeListener((items, count, sub) -> {});
    }
}
