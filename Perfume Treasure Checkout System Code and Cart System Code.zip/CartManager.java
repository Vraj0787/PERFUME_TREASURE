package com.perfumetreasure.app.cart;

import com.perfumetreasure.app.models.CartItem;
import com.perfumetreasure.app.models.Perfume;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * CartManager — thread-safe singleton that owns the in-memory cart state.
 *
 * <p>Responsibilities:
 * <ul>
 *   <li>Add / remove / update cart items</li>
 *   <li>Enforce stock limits</li>
 *   <li>Compute subtotals</li>
 *   <li>Notify registered {@link CartChangeListener}s after every mutation</li>
 * </ul>
 *
 * <p>Persistence: the cart is kept in memory during the session.
 * Serialise {@link #getItems()} to SharedPreferences / Room DB in the
 * {@code CartRepository} layer when the app backgrounds.
 */
public class CartManager {

    // ── Singleton ─────────────────────────────────────────────────────────────

    private static volatile CartManager instance;

    private CartManager() {}

    public static CartManager getInstance() {
        if (instance == null) {
            synchronized (CartManager.class) {
                if (instance == null) instance = new CartManager();
            }
        }
        return instance;
    }

    // ── State ─────────────────────────────────────────────────────────────────

    private final List<CartItem>           items     = new ArrayList<>();
    private final List<CartChangeListener> listeners = new ArrayList<>();

    // ── Listener contract ─────────────────────────────────────────────────────

    public interface CartChangeListener {
        /**
         * Fired on the calling thread after any cart mutation.
         *
         * @param items      current snapshot (unmodifiable)
         * @param itemCount  total number of individual units
         * @param subtotal   pre-tax, pre-shipping subtotal
         */
        void onCartChanged(List<CartItem> items, int itemCount, double subtotal);
    }

    public void addListener(CartChangeListener l)    { if (!listeners.contains(l)) listeners.add(l); }
    public void removeListener(CartChangeListener l) { listeners.remove(l); }

    private void notifyListeners() {
        List<CartItem> snap = Collections.unmodifiableList(new ArrayList<>(items));
        int   count    = getTotalItemCount();
        double sub     = getSubtotal();
        for (CartChangeListener l : listeners) l.onCartChanged(snap, count, sub);
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Add {@code quantity} units of {@code perfume} to the cart.
     * If the perfume is already in the cart the quantity is incremented.
     *
     * @throws IllegalArgumentException if perfume is null or quantity < 1
     * @throws IllegalStateException    if resulting quantity would exceed stock
     */
    public synchronized void addItem(Perfume perfume, int quantity) {
        if (perfume == null)  throw new IllegalArgumentException("Perfume must not be null.");
        if (quantity < 1)     throw new IllegalArgumentException("Quantity must be >= 1.");

        Optional<CartItem> existing = findById(perfume.getId());
        if (existing.isPresent()) {
            existing.get().incrementQuantity(quantity);   // throws if over stock
        } else {
            if (quantity > perfume.getStockQuantity()) {
                throw new IllegalStateException(
                    "Cannot add " + quantity + " units; only "
                    + perfume.getStockQuantity() + " in stock.");
            }
            items.add(new CartItem(perfume, quantity));
        }
        notifyListeners();
    }

    /** Convenience: add 1 unit */
    public synchronized void addItem(Perfume perfume) {
        addItem(perfume, 1);
    }

    /**
     * Remove the item for {@code perfumeId} entirely from the cart.
     * No-op if the perfume is not in the cart.
     */
    public synchronized void removeItem(String perfumeId) {
        boolean removed = items.removeIf(i -> i.getPerfume().getId().equals(perfumeId));
        if (removed) notifyListeners();
    }

    /**
     * Set an item's quantity to an exact value.
     * Pass 0 (or negative) to remove it.
     */
    public synchronized void updateQuantity(String perfumeId, int newQuantity) {
        if (newQuantity <= 0) {
            removeItem(perfumeId);
            return;
        }
        findById(perfumeId).ifPresent(item -> {
            item.setQuantity(newQuantity);
            notifyListeners();
        });
    }

    /** Increment a specific item's quantity by 1. */
    public synchronized void incrementItem(String perfumeId) {
        findById(perfumeId).ifPresent(item -> {
            item.incrementQuantity(1);
            notifyListeners();
        });
    }

    /** Decrement a specific item's quantity by 1 (removes it when it reaches 0). */
    public synchronized void decrementItem(String perfumeId) {
        Optional<CartItem> opt = findById(perfumeId);
        opt.ifPresent(item -> {
            if (item.getQuantity() <= 1) {
                removeItem(perfumeId);
            } else {
                item.decrementQuantity(1);
                notifyListeners();
            }
        });
    }

    /** Remove all items from the cart. */
    public synchronized void clearCart() {
        if (!items.isEmpty()) {
            items.clear();
            notifyListeners();
        }
    }

    // ── Queries ───────────────────────────────────────────────────────────────

    /** Immutable snapshot of current items. */
    public synchronized List<CartItem> getItems() {
        return Collections.unmodifiableList(new ArrayList<>(items));
    }

    /** True when the cart contains no items. */
    public synchronized boolean isEmpty() {
        return items.isEmpty();
    }

    /** Total number of individual units across all line items. */
    public synchronized int getTotalItemCount() {
        return items.stream().mapToInt(CartItem::getQuantity).sum();
    }

    /** Number of distinct perfumes (line items) in the cart. */
    public synchronized int getDistinctItemCount() {
        return items.size();
    }

    /** Pre-tax, pre-shipping subtotal. */
    public synchronized double getSubtotal() {
        return items.stream().mapToDouble(CartItem::getLineTotal).sum();
    }

    /** Formatted subtotal string, e.g. "$189.97" */
    public synchronized String getFormattedSubtotal() {
        return String.format("$%.2f", getSubtotal());
    }

    /** True if the cart contains at least one unit of the given perfume. */
    public synchronized boolean containsPerfume(String perfumeId) {
        return findById(perfumeId).isPresent();
    }

    /** How many units of a specific perfume are currently in the cart (0 if absent). */
    public synchronized int getQuantityFor(String perfumeId) {
        return findById(perfumeId).map(CartItem::getQuantity).orElse(0);
    }

    // ── Internal helpers ──────────────────────────────────────────────────────

    private Optional<CartItem> findById(String perfumeId) {
        return items.stream()
                    .filter(i -> i.getPerfume().getId().equals(perfumeId))
                    .findFirst();
    }
}
