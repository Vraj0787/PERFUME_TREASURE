package com.perfumetreasure.app.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.perfumetreasure.app.R;
import com.perfumetreasure.app.models.CartItem;

/**
 * CartAdapter — RecyclerView adapter for the cart screen.
 *
 * Uses {@link ListAdapter} + {@link DiffUtil} for efficient, animated updates
 * whenever the cart changes.
 *
 * Layout file expected: {@code res/layout/item_cart.xml}
 * Required view IDs (see XML snippet in README):
 *   - iv_perfume_image    (ImageView)
 *   - tv_perfume_name     (TextView)
 *   - tv_perfume_brand    (TextView)
 *   - tv_perfume_size     (TextView)
 *   - tv_line_total       (TextView)
 *   - tv_quantity         (TextView)
 *   - btn_increment       (ImageButton / Button)
 *   - btn_decrement       (ImageButton / Button)
 *   - btn_remove          (ImageButton)
 */
public class CartAdapter extends ListAdapter<CartItem, CartAdapter.CartViewHolder> {

    // ── Listener interface ────────────────────────────────────────────────────

    public interface CartItemListener {
        void onIncrement(String perfumeId);
        void onDecrement(String perfumeId);
        void onRemove(String perfumeId);
    }

    private final CartItemListener listener;

    public CartAdapter(@NonNull CartItemListener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    // ── DiffUtil ──────────────────────────────────────────────────────────────

    private static final DiffUtil.ItemCallback<CartItem> DIFF_CALLBACK =
        new DiffUtil.ItemCallback<CartItem>() {
            @Override
            public boolean areItemsTheSame(@NonNull CartItem a, @NonNull CartItem b) {
                return a.getPerfume().getId().equals(b.getPerfume().getId());
            }

            @Override
            public boolean areContentsTheSame(@NonNull CartItem a, @NonNull CartItem b) {
                return a.getQuantity() == b.getQuantity() &&
                       Double.compare(a.getLineTotal(), b.getLineTotal()) == 0;
            }
        };

    // ── Adapter overrides ─────────────────────────────────────────────────────

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                                  .inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        holder.bind(getItem(position), listener);
    }

    // ── ViewHolder ────────────────────────────────────────────────────────────

    static class CartViewHolder extends RecyclerView.ViewHolder {

        private final ImageView   ivImage;
        private final TextView    tvName;
        private final TextView    tvBrand;
        private final TextView    tvSize;
        private final TextView    tvLineTotal;
        private final TextView    tvQuantity;
        private final ImageButton btnIncrement;
        private final ImageButton btnDecrement;
        private final ImageButton btnRemove;

        CartViewHolder(@NonNull View itemView) {
            super(itemView);
            ivImage      = itemView.findViewById(R.id.iv_perfume_image);
            tvName       = itemView.findViewById(R.id.tv_perfume_name);
            tvBrand      = itemView.findViewById(R.id.tv_perfume_brand);
            tvSize       = itemView.findViewById(R.id.tv_perfume_size);
            tvLineTotal  = itemView.findViewById(R.id.tv_line_total);
            tvQuantity   = itemView.findViewById(R.id.tv_quantity);
            btnIncrement = itemView.findViewById(R.id.btn_increment);
            btnDecrement = itemView.findViewById(R.id.btn_decrement);
            btnRemove    = itemView.findViewById(R.id.btn_remove);
        }

        void bind(CartItem item, CartItemListener listener) {
            String id = item.getPerfume().getId();

            tvName.setText(item.getPerfume().getName());
            tvBrand.setText(item.getPerfume().getBrand());
            tvSize.setText(item.getPerfume().getVolumeMl() + "ml · "
                           + item.getPerfume().getConcentration());
            tvLineTotal.setText(item.getFormattedLineTotal());
            tvQuantity.setText(String.valueOf(item.getQuantity()));

            // Load image with your preferred image library, e.g.:
            // Glide.with(ivImage).load(item.getPerfume().getImageUrl())
            //      .placeholder(R.drawable.ic_perfume_placeholder).into(ivImage);

            // Disable decrement at 1 so it looks like "will remove"
            btnDecrement.setAlpha(item.getQuantity() == 1 ? 0.4f : 1.0f);

            btnIncrement.setOnClickListener(v -> listener.onIncrement(id));
            btnDecrement.setOnClickListener(v -> listener.onDecrement(id));
            btnRemove.setOnClickListener(v   -> listener.onRemove(id));
        }
    }
}
