package com.perfumetreasure.app.checkout;

import com.perfumetreasure.app.cart.CartManager;
import com.perfumetreasure.app.models.CartItem;
import com.perfumetreasure.app.models.Order;

import java.util.ArrayList;
import java.util.List;

/**
 * CheckoutManager — orchestrates the multi-step checkout flow.
 *
 * Steps:
 *   1. {@link #setShippingAddress}  — collect delivery details
 *   2. {@link #setShippingMethod}   — choose Standard / Express / Overnight
 *   3. {@link #applyCoupon}         — optional discount code
 *   4. {@link #setPaymentMethod}    — set tokenised payment details
 *   5. {@link #buildOrderPreview}   — get full pricing summary before payment
 *   6. {@link #placeOrder}          — submit the order
 *
 * All heavy I/O (network, persistence) is delegated to injected service
 * interfaces so this class stays testable and framework-agnostic.
 */
public class CheckoutManager {

    // ── Injected services ─────────────────────────────────────────────────────

    /** Submits a fully built {@link Order} to the backend. */
    public interface OrderService {
        /**
         * @param order     the fully priced, validated order
         * @param callback  receives the confirmed order or an error message
         */
        void submitOrder(Order order, OrderCallback callback);
    }

    public interface OrderCallback {
        void onSuccess(Order confirmedOrder);
        void onFailure(String errorMessage);
    }

    // ── Dependencies ──────────────────────────────────────────────────────────

    private final CartManager    cartManager;
    private final CouponEngine   couponEngine;
    private final PricingEngine  pricingEngine;
    private final OrderService   orderService;

    // ── Mutable checkout state ────────────────────────────────────────────────

    private Order.ShippingAddress  shippingAddress;
    private Order.PaymentMethod    paymentMethod;
    private PricingEngine.ShippingMethod shippingMethod = PricingEngine.ShippingMethod.STANDARD;

    private CouponEngine.CouponResult appliedCoupon;

    public CheckoutManager(CartManager cartManager,
                           CouponEngine couponEngine,
                           PricingEngine pricingEngine,
                           OrderService orderService) {
        this.cartManager   = cartManager;
        this.couponEngine  = couponEngine;
        this.pricingEngine = pricingEngine;
        this.orderService  = orderService;
    }

    // ── Step 1: Shipping address ──────────────────────────────────────────────

    /**
     * @throws IllegalArgumentException if the address is incomplete
     */
    public void setShippingAddress(Order.ShippingAddress address) {
        if (address == null || !address.isComplete()) {
            throw new IllegalArgumentException("Please fill in all required address fields.");
        }
        this.shippingAddress = address;
    }

    public Order.ShippingAddress getShippingAddress() { return shippingAddress; }

    // ── Step 2: Shipping method ───────────────────────────────────────────────

    public void setShippingMethod(PricingEngine.ShippingMethod method) {
        this.shippingMethod = (method != null) ? method : PricingEngine.ShippingMethod.STANDARD;
    }

    public PricingEngine.ShippingMethod getShippingMethod() { return shippingMethod; }

    public double getShippingCostPreview() {
        boolean freeShip = appliedCoupon != null && appliedCoupon.isFreeShipping();
        return pricingEngine.calculateShipping(cartManager.getSubtotal(), shippingMethod, freeShip);
    }

    // ── Step 3: Coupon ────────────────────────────────────────────────────────

    /**
     * Attempt to apply a coupon code.
     *
     * @return the result (always non-null); check {@link CouponEngine.CouponResult#isValid()}
     */
    public CouponEngine.CouponResult applyCoupon(String code) {
        CouponEngine.CouponResult result =
            couponEngine.apply(code, cartManager.getSubtotal(), cartManager.getItems());
        if (result.isValid()) {
            appliedCoupon = result;
        }
        return result;
    }

    public void removeCoupon() {
        appliedCoupon = null;
    }

    public CouponEngine.CouponResult getAppliedCoupon() { return appliedCoupon; }

    // ── Step 4: Payment method ────────────────────────────────────────────────

    public void setPaymentMethod(Order.PaymentMethod method) {
        if (method == null) throw new IllegalArgumentException("Payment method must not be null.");
        this.paymentMethod = method;
    }

    public Order.PaymentMethod getPaymentMethod() { return paymentMethod; }

    // ── Step 5: Order preview ─────────────────────────────────────────────────

    /**
     * Build a fully priced {@link Order} object from current checkout state.
     * Call this to show the "Order Summary" confirmation screen.
     *
     * @throws IllegalStateException if prerequisites are missing
     */
    public Order buildOrderPreview() {
        validate();

        double subtotal      = cartManager.getSubtotal();
        double discountAmt   = appliedCoupon != null ? appliedCoupon.getDiscountAmount() : 0;
        boolean freeShip     = appliedCoupon != null && appliedCoupon.isFreeShipping();

        PricingEngine.PricingResult pricing =
            pricingEngine.calculate(subtotal, discountAmt, shippingMethod, freeShip, shippingAddress);

        Order order = new Order();
        order.setItems(new ArrayList<>(cartManager.getItems()));
        order.setShippingAddress(shippingAddress);
        order.setPaymentMethod(paymentMethod);

        if (appliedCoupon != null) {
            order.setCouponCode(appliedCoupon.getCoupon().getCode());
        }

        pricingEngine.applyToOrder(order, pricing);
        order.setStatus(Order.Status.PENDING);

        return order;
    }

    // ── Step 6: Place order ───────────────────────────────────────────────────

    /**
     * Finalise and submit the order.
     *
     * <p>On success the cart is cleared automatically.
     *
     * @param callback invoked (on the calling thread) with the result
     */
    public void placeOrder(OrderCallback callback) {
        Order order;
        try {
            order = buildOrderPreview();
        } catch (IllegalStateException e) {
            callback.onFailure(e.getMessage());
            return;
        }

        orderService.submitOrder(order, new OrderCallback() {
            @Override
            public void onSuccess(Order confirmedOrder) {
                cartManager.clearCart();
                callback.onSuccess(confirmedOrder);
            }

            @Override
            public void onFailure(String errorMessage) {
                callback.onFailure(errorMessage);
            }
        });
    }

    // ── Validation ────────────────────────────────────────────────────────────

    private void validate() {
        List<String> errors = new ArrayList<>();

        if (cartManager.isEmpty())            errors.add("Your cart is empty.");
        if (shippingAddress == null)          errors.add("Please add a shipping address.");
        if (paymentMethod == null)            errors.add("Please select a payment method.");

        // Stock check
        for (CartItem item : cartManager.getItems()) {
            if (item.exceedsStock()) {
                errors.add("\"" + item.getPerfume().getName() + "\" has insufficient stock.");
            }
        }

        if (!errors.isEmpty()) {
            throw new IllegalStateException(String.join("\n", errors));
        }
    }

    // ── Convenience ───────────────────────────────────────────────────────────

    public boolean isReadyToPlace() {
        try { validate(); return true; }
        catch (IllegalStateException e) { return false; }
    }

    /** Reset checkout state (address, coupon, payment) without touching the cart. */
    public void reset() {
        shippingAddress = null;
        paymentMethod   = null;
        shippingMethod  = PricingEngine.ShippingMethod.STANDARD;
        appliedCoupon   = null;
    }
}
