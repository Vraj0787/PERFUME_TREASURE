package com.perfumetreasure.app.models;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

/**
 * Represents a completed (or pending) customer order.
 */
public class Order implements Serializable {

    // ── Status enum ────────────────────────────────────────────────────────────
    public enum Status {
        PENDING,
        PAYMENT_PROCESSING,
        CONFIRMED,
        SHIPPED,
        DELIVERED,
        CANCELLED,
        REFUNDED
    }

    private String           orderId;
    private String           userId;
    private List<CartItem>   items;
    private ShippingAddress  shippingAddress;
    private PaymentMethod    paymentMethod;
    private Status           status;

    // Financials
    private double subtotal;
    private double discountAmount;
    private String couponCode;
    private double shippingCost;
    private double taxAmount;
    private double total;

    private long   createdAtMs;
    private long   updatedAtMs;
    private String trackingNumber;

    public Order() {
        this.orderId     = UUID.randomUUID().toString();
        this.status      = Status.PENDING;
        this.createdAtMs = System.currentTimeMillis();
        this.updatedAtMs = this.createdAtMs;
    }

    // ─── Formatted helpers ──────────────────────────────────────────────────────

    public String getFormattedSubtotal()  { return String.format("$%.2f", subtotal); }
    public String getFormattedDiscount()  { return String.format("-$%.2f", discountAmount); }
    public String getFormattedShipping()  {
        return shippingCost == 0 ? "FREE" : String.format("$%.2f", shippingCost);
    }
    public String getFormattedTax()       { return String.format("$%.2f", taxAmount); }
    public String getFormattedTotal()     { return String.format("$%.2f", total); }

    public boolean hasDiscount()          { return discountAmount > 0; }
    public int     getTotalItemCount()    {
        if (items == null) return 0;
        return items.stream().mapToInt(CartItem::getQuantity).sum();
    }

    // ─── Getters / Setters ──────────────────────────────────────────────────────

    public String          getOrderId()          { return orderId; }
    public String          getUserId()           { return userId; }
    public List<CartItem>  getItems()            { return items; }
    public ShippingAddress getShippingAddress()  { return shippingAddress; }
    public PaymentMethod   getPaymentMethod()    { return paymentMethod; }
    public Status          getStatus()           { return status; }
    public double          getSubtotal()         { return subtotal; }
    public double          getDiscountAmount()   { return discountAmount; }
    public String          getCouponCode()       { return couponCode; }
    public double          getShippingCost()     { return shippingCost; }
    public double          getTaxAmount()        { return taxAmount; }
    public double          getTotal()            { return total; }
    public long            getCreatedAtMs()      { return createdAtMs; }
    public long            getUpdatedAtMs()      { return updatedAtMs; }
    public String          getTrackingNumber()   { return trackingNumber; }

    public void setUserId(String userId)                    { this.userId = userId; }
    public void setItems(List<CartItem> items)              { this.items = items; }
    public void setShippingAddress(ShippingAddress addr)    { this.shippingAddress = addr; }
    public void setPaymentMethod(PaymentMethod method)      { this.paymentMethod = method; }
    public void setStatus(Status status)                    {
        this.status = status;
        this.updatedAtMs = System.currentTimeMillis();
    }
    public void setSubtotal(double subtotal)                { this.subtotal = subtotal; }
    public void setDiscountAmount(double amount)            { this.discountAmount = amount; }
    public void setCouponCode(String code)                  { this.couponCode = code; }
    public void setShippingCost(double shippingCost)        { this.shippingCost = shippingCost; }
    public void setTaxAmount(double taxAmount)              { this.taxAmount = taxAmount; }
    public void setTotal(double total)                      { this.total = total; }
    public void setTrackingNumber(String trackingNumber)    { this.trackingNumber = trackingNumber; }


    // ══════════════════════════════════════════════════════════════════════════
    //  Nested: ShippingAddress
    // ══════════════════════════════════════════════════════════════════════════

    public static class ShippingAddress implements Serializable {
        private String fullName;
        private String line1;
        private String line2;
        private String city;
        private String state;
        private String postalCode;
        private String country;
        private String phone;

        public ShippingAddress() {}

        public ShippingAddress(String fullName, String line1, String city,
                               String state, String postalCode, String country, String phone) {
            this.fullName   = fullName;
            this.line1      = line1;
            this.city       = city;
            this.state      = state;
            this.postalCode = postalCode;
            this.country    = country;
            this.phone      = phone;
        }

        /** Single-string summary for display in the checkout screen */
        public String getSummary() {
            StringBuilder sb = new StringBuilder();
            sb.append(fullName).append("\n");
            sb.append(line1);
            if (line2 != null && !line2.isEmpty()) sb.append(", ").append(line2);
            sb.append("\n").append(city).append(", ").append(state)
              .append(" ").append(postalCode).append("\n").append(country);
            return sb.toString();
        }

        public boolean isComplete() {
            return fullName   != null && !fullName.isBlank()   &&
                   line1      != null && !line1.isBlank()      &&
                   city       != null && !city.isBlank()       &&
                   state      != null && !state.isBlank()      &&
                   postalCode != null && !postalCode.isBlank() &&
                   country    != null && !country.isBlank();
        }

        // Getters
        public String getFullName()   { return fullName; }
        public String getLine1()      { return line1; }
        public String getLine2()      { return line2; }
        public String getCity()       { return city; }
        public String getState()      { return state; }
        public String getPostalCode() { return postalCode; }
        public String getCountry()    { return country; }
        public String getPhone()      { return phone; }

        // Setters
        public void setFullName(String fullName)     { this.fullName = fullName; }
        public void setLine1(String line1)           { this.line1 = line1; }
        public void setLine2(String line2)           { this.line2 = line2; }
        public void setCity(String city)             { this.city = city; }
        public void setState(String state)           { this.state = state; }
        public void setPostalCode(String postalCode) { this.postalCode = postalCode; }
        public void setCountry(String country)       { this.country = country; }
        public void setPhone(String phone)           { this.phone = phone; }
    }


    // ══════════════════════════════════════════════════════════════════════════
    //  Nested: PaymentMethod
    // ══════════════════════════════════════════════════════════════════════════

    public static class PaymentMethod implements Serializable {

        public enum Type { CREDIT_CARD, DEBIT_CARD, PAYPAL, APPLE_PAY, GOOGLE_PAY }

        private Type   type;
        private String cardLastFour;   // only for card types
        private String cardholderName;
        private String expiryMM;
        private String expiryYY;
        private String paymentToken;   // tokenised by payment gateway (never store raw PAN)

        public PaymentMethod() {}

        public PaymentMethod(Type type, String paymentToken) {
            this.type         = type;
            this.paymentToken = paymentToken;
        }

        /** Human-readable summary, e.g., "Visa •••• 4242" or "Apple Pay" */
        public String getDisplayLabel() {
            if (type == Type.CREDIT_CARD || type == Type.DEBIT_CARD) {
                return (type == Type.CREDIT_CARD ? "Credit Card" : "Debit Card")
                       + (cardLastFour != null ? " •••• " + cardLastFour : "");
            }
            return type.name().replace("_", " ");
        }

        // Getters
        public Type   getType()            { return type; }
        public String getCardLastFour()    { return cardLastFour; }
        public String getCardholderName()  { return cardholderName; }
        public String getExpiryMM()        { return expiryMM; }
        public String getExpiryYY()        { return expiryYY; }
        public String getPaymentToken()    { return paymentToken; }

        // Setters
        public void setType(Type type)                       { this.type = type; }
        public void setCardLastFour(String last4)            { this.cardLastFour = last4; }
        public void setCardholderName(String name)           { this.cardholderName = name; }
        public void setExpiryMM(String mm)                   { this.expiryMM = mm; }
        public void setExpiryYY(String yy)                   { this.expiryYY = yy; }
        public void setPaymentToken(String token)            { this.paymentToken = token; }
    }
}
